John Ohanian
205505819

NOTES: I had to change index.js as it kept adding new copies of the same cards everytime the page was refreshed. 
It now adds a dumbie card, then deletes it(so that the linter won't get mad);